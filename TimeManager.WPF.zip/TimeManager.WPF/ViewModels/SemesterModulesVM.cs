﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using TimeManager.MainLibrary.Dtos;
using TimeManager.MainLibrary.Services;
using TimeManager.WPF.Commands;

namespace TimeManager.WPF.ViewModels
{
    public class SemesterModulesVM : INotifyPropertyChanged
    {
        private ObservableCollection<UserModuleDto> _userModules;

        public ObservableCollection<UserModuleDto> UserModules
        {
            get { return _userModules; }
            set
            {
                if (_userModules != value)
                {
                    _userModules = value;
                    OnPropertyChanged(nameof(UserModules));
                }
            }
        }

        public ICommand ShowAddModuleWindow { get; set; }
        public ICommand ShowCaptureHoursWindow { get; set; }

        public SemesterModulesVM()
        {
            UserModules = GetUsersModules();
            ShowAddModuleWindow = new RelayCommand(ViewModules, canViewModules);
            ShowCaptureHoursWindow = new RelayCommand(ViewCaptureHours, CanViewCaptureHours);
            RefreshUserModules();
        }

        private bool CanViewCaptureHours(object arg)
        {
            return true;
        }

        private void ViewCaptureHours(object obj)
        {
            var mainWindow = obj as Window;
            LogHours logHoursScreen = new LogHours();
            logHoursScreen.Owner = mainWindow;
            logHoursScreen.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            logHoursScreen.Closed += WindowRefresher;
            logHoursScreen.Show();
        }

        private bool canViewModules(object arg)
        {
            return true;
        }

        private void ViewModules(object obj)
        {
            var mainWindow = obj as Window;
            AddModule addModuleWindow = new AddModule();
            addModuleWindow.Owner = mainWindow;
            addModuleWindow.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            addModuleWindow.Closed += WindowRefresher;
            addModuleWindow.Show(); 
        }

        private void WindowRefresher(object sender, EventArgs e)
        {
            // Cast the sender to a Window if necessary
            var window = sender as Window;

            // Unsubscribe from the Closed event to prevent memory leaks (optional)
            window.Closed -= WindowRefresher;

            // Call GetUsersModules to refresh the user modules
            RefreshUserModules();
        }

        private void RefreshUserModules()
        {
            var modulesFromDb = ModuleService.ListAllUserModules(1, DateTime.Now);
            if (modulesFromDb.IsSuccsesful)
            {
                var data = modulesFromDb.Data as IEnumerable<UserModuleDto>;
                UserModules.Clear();
                foreach (var module in data)
                {
                    UserModules.Add(module);
                }
            }
            else
            {
                MessageBox.Show("Could not load the user's modules");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }  

        private ObservableCollection<UserModuleDto> GetUsersModules()
        {
            var modulesFromDb = ModuleService.ListAllUserModules(1, DateTime.Now);
            if (modulesFromDb.IsSuccsesful)
            {
                var data = modulesFromDb.Data as IEnumerable<UserModuleDto>;
                var dataToCollection = new ObservableCollection<UserModuleDto>(data);
                return dataToCollection;
            }else
            {
                MessageBox.Show("Could not load the users modules");
                return null;
            }
        }
    }
}
