﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using TimeManager.MainLibrary.Dtos;
using TimeManager.MainLibrary.Services;
using TimeManager.WPF.Commands;

namespace TimeManager.WPF.ViewModels
{
    public class LogHoursVM : INotifyPropertyChanged , IDataErrorInfo
    {
        public event EventHandler RequestClose;
        public ICommand LogHoursCommand { get; set; }
        public ICommand CancelCommand { get; set; }

        private ObservableCollection<UserModuleDto> _userModules;
        public ObservableCollection<UserModuleDto> UserModules
        {
            get { return _userModules; }
            set
            {
                _userModules = value;
                OnPropertyChanged();
            }
        }

        private UserModuleDto _selectedModule;
        public UserModuleDto SelectedModule
        {
            get { return _selectedModule; }
            set
            {
                _selectedModule = value;
                OnPropertyChanged(nameof(SelectedModule));
                OnPropertyChanged(nameof(HoursRemainingText));
                OnPropertyChanged(nameof(SelectedModuleErrorMessage));
                CalculateRemainingHours();
            }
        }


        public DateTime SelectedDate { get; set; } = DateTime.Now;

        private double _hoursSpent = 0;
        public double HoursSpent
        {
            get { return _hoursSpent; }
            set
            {
                _hoursSpent = value;
                CalculateRemainingHours();
                OnPropertyChanged();
            }
        }

        private string _hoursSpentInput;
        public string HoursSpentInput 
        { 
            get
            {
                return _hoursSpentInput;    
            }
            set
            {
                _hoursSpentInput = value;
                OnPropertyChanged();
            }
        }


        private string _hoursSpentInputError;
        public string HoursSpentInputError
        {
            get
            {
                return _hoursSpentInputError;
            }
            set
            {   
                _hoursSpentInputError = value;
                OnPropertyChanged();
            }
        }


        private string _hoursRemainingText;
        public string HoursRemainingText
        {
            get
            {
                return _hoursRemainingText;
            }
            set
            {
                _hoursRemainingText = value;
                OnPropertyChanged();
            }
        }


        private Brush _hoursRemainingColor;
        public Brush HoursRemainingColor
        {
            get
            {
                return _hoursRemainingColor; 
            }
            set 
            {
                OnPropertyChanged(); 
            } 
        }
          

        private string _selectedModuleErrorMessage;
        public string SelectedModuleErrorMessage 
        { 
            get 
            { 
                return _selectedModuleErrorMessage; 
            }
            set 
            { 
                _selectedModuleErrorMessage = value; 
                OnPropertyChanged(); 
            }
        }

        public string Error => null;

        public string this[string columnName]
        {
            get
            {
                if(columnName == nameof(HoursSpentInput))
                {
                    string errorMessage = String.Empty;
                    double hoursSpent;

                    if(SelectedModule == null)
                    {
                        errorMessage = "Please select a module first from the list";
                    }

                    if(!double.TryParse(HoursSpentInput, out hoursSpent))
                    {
                        errorMessage = "Please enter a valid number";
                        hoursSpent = 0;
                    }

                    if(hoursSpent < 0) 
                    {
                        errorMessage = "Hours spent cannot be negative";
                    }

                    if(SelectedModule != null)
                    {
                        if(hoursSpent > SelectedModule.HoursRemaining)
                        {
                            errorMessage = "Hours spent cannot be more than the remaining hours";
                        }
                    }
                    HoursSpentInputError = errorMessage;
                    if (String.IsNullOrEmpty(errorMessage))
                    {
                        HoursSpent = hoursSpent;
                    }else
                    {
                        HoursSpent = 0;
                    }

                    return errorMessage;
                }


                if(columnName == nameof(SelectedModule))
                {
                    string errorMessage = String.Empty;
                    if(SelectedModule == null)
                    {
                        errorMessage = "Please select a module to record time";
                    }

                    SelectedModuleErrorMessage = errorMessage;
                    return errorMessage;
                }  


                return null;
            }
        }

        public LogHoursVM()
        {
 
            UserModules = GetUsersModules();
            LogHoursCommand = new RelayCommand(Submit, CanSubmit);
            CancelCommand = new RelayCommand(Cancel, CanCancel);
        }

        private bool CanCancel(object arg)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            RequestClose?.Invoke(this, EventArgs.Empty);
        }

        private bool CanSubmit(object arg)
        {
            return true;
        }

        private void Submit(object obj)
        {

            if (SelectedModule == null)
            {
                MessageBox.Show("Please select a module to continue", "Validation error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            } 

            if(SelectedDate == null)
            {
                MessageBox.Show("Please select a date", "Validation error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if(HoursSpent  <= 0)
            {
                MessageBox.Show("Please enter a valid value for the hours to continue", "Validation error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            
   
            var selectedModuleId = SelectedModule.ModuleId;
            var selectedDate = SelectedDate;  
            var hoursSpent = HoursSpent; 


            var newHours = new LogHoursDto
            {
                ModuleId = selectedModuleId,
                Date = selectedDate,
                HoursSpent = hoursSpent,
                LoggedInUserId = 1
            }; 

            var data = LogginService.LogHours(newHours);

            if (data.IsSuccsesful)
            {
                MessageBox.Show(data.Message, "Success", MessageBoxButton.OK, MessageBoxImage.Information); 
                return;
            }else
            {
                MessageBox.Show(data.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

           
        }

        private ObservableCollection<UserModuleDto> GetUsersModules()
        {

            var modulesFromDb = ModuleService.ListAllUserModules(1, DateTime.Now);
            if (modulesFromDb.IsSuccsesful)
            {
                var data = modulesFromDb.Data as IEnumerable<UserModuleDto>;
                var dataToCollection = new ObservableCollection<UserModuleDto>(data);
                return dataToCollection;
            }
            else
            {
                MessageBox.Show("Could not load the users modules");
                return null;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


        private void CalculateRemainingHours()
        {
            if (SelectedModule != null)
            {
                double remainingHours = SelectedModule.HoursRemaining - HoursSpent;
                HoursRemainingText = remainingHours.ToString();       
            }
        }



    }
}
     